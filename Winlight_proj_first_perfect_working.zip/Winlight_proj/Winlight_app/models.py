from django.db import models

# Create your models here.
from django.db import models

class RecentWork(models.Model):
    title = models.CharField(max_length=200)
    image = models.ImageField(upload_to='recent_work/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-uploaded_at']

    def __str__(self):
        return self.title

class UpcomingProject(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    cover_image = models.ImageField(upload_to='upcoming_projects/')
    release_expected = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return self.title

class CrewMember(models.Model):
    name = models.CharField(max_length=150)
    role = models.CharField(max_length=150)
    photo = models.ImageField(upload_to='crew/')
    display_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['display_order', 'name']

    def __str__(self):
        return f"{self.name} - {self.role}"

class Article(models.Model):
    title = models.CharField(max_length=250)
    summary = models.TextField(max_length=500)
    content = models.TextField()
    thumbnail = models.ImageField(upload_to='articles/')
    published_date = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-published_date']

    def __str__(self):
        return self.title