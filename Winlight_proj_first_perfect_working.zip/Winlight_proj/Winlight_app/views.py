from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import RecentWork, UpcomingProject, CrewMember, Article
from .forms import RecentWorkForm, UpcomingProjectForm, CrewMemberForm, ArticleForm

def studio_home(request):
    recent_works = RecentWork.objects.all()
    upcoming_projects = UpcomingProject.objects.all()
    crew_members = CrewMember.objects.all()
    articles = Article.objects.all()

    if request.method == 'POST':
        form_type = request.POST.get('form_id')
        
        if form_type == 'recent_work_submit':
            form = RecentWorkForm(request.POST, request.FILES)
            if form.is_valid():
                form.save()
                messages.success(request, "Portfolio item added successfully.")
                return redirect('studio_home')
        
        elif form_type == 'upcoming_project_submit':
            form = UpcomingProjectForm(request.POST, request.FILES)
            if form.is_valid():
                form.save()
                messages.success(request, "Upcoming project logged successfully.")
                return redirect('studio_home')

        elif form_type == 'crew_submit':
            form = CrewMemberForm(request.POST, request.FILES)
            if form.is_valid():
                form.save()
                messages.success(request, "Crew profile saved successfully.")
                return redirect('studio_home')

        elif form_type == 'article_submit':
            form = ArticleForm(request.POST, request.FILES)
            if form.is_valid():
                form.save()
                messages.success(request, "Editorial story published successfully.")
                return redirect('studio_home')
    
    context = {
        'recent_works': recent_works,
        'upcoming_projects': upcoming_projects,
        'crew_members': crew_members,
        'articles': articles,
        'recent_form': RecentWorkForm(),
        'upcoming_form': UpcomingProjectForm(),
        'crew_form': CrewMemberForm(),
        'article_form': ArticleForm(),
    }
    return render(request, 'Winlight_app/index.html', context)